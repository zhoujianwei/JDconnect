﻿<?xml version="1.0" encoding="utf-8" ?>
<install version="1.5" type="plugin" group="user">
    <name>JD UCenter Control</name>
    <author>www.joomladrupal.com</author>
    <creationDate>2011.4</creationDate>
    <license>http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL</license>
    <authorEmail>www.joomladrupal.com</authorEmail>
    <authorUrl>www.joomladrupal.com</authorUrl>
    <version>1.5</version>
    <description>本款桥接器为Joomla&Drupal教程网制作并发布！具体说明请至www.joomladrupal.com查看</description>
    <files>
        <filename plugin="ucenter_control">ucenter_control.php</filename>
    </files>
    <params></params>
</install>

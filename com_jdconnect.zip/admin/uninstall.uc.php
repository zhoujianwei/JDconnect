<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
// No direct access allowed to this file
defined('_JEXEC') or die('Restricted access');

function com_uninstall() {
    jimport('joomla.filesystem.file');
    jimport('joomla.filesystem.folder');
    //
    $path1 = JPATH_PLUGINS . DS . 'authentication';
    JFile::delete($path1 . DS . 'joomla.php');
    JFile::move($path1 . DS . 'joomla.php.bk', $path1 . DS . 'joomla.php');

    $path1 = JPATH_ROOT . DS . 'components' . DS . 'com_user';
    JFile::delete($path1 . DS . 'controller.php');
    JFile::move($path1 . DS . 'controller.php.bk', $path1 . DS . 'controller.php');
    //
    JFolder::delete(JPATH_ROOT . DS . 'uc_client');
    JFolder::delete(JPATH_ROOT . DS . 'api');
    // plugins uninstall
    JFile::delete(JPATH_PLUGINS . DS . 'user' . DS . 'ucenter_control.xml');
    JFile::delete(JPATH_PLUGINS . DS . 'user' . DS . 'ucenter_control.php');

    $db = & JFactory::getDBO();
    $sql = "DELETE FROM `#__plugins` WHERE element='ucenter_control' AND folder='user'";
    $db->setQuery($sql);
    $db->Query();
}

?>

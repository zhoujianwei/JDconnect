<?php

//用户是否存在于joomla users表中，若不存在则添加并予随机密码
// @param object(id, username,email)
// @return 
function checkuserexists_user(&$activeuser) {
    $database = & JFactory::getDBO();
    ;
    list($id, $username, $email) = $activeuser;

    $database->setQuery("select id from #__users where username='$username'");

    if (!$database->loadResult()) {
        $password = md5(time() . rand(100000, 999999));
        $database->setQuery("insert into #__users (name, username, password, email, usertype, gid, block) values('$username', '$username', '$password', '$email', 'Registered', 18, 0);");
        $database->query();
        $idLocal = $database->insertid();

        $database->setQuery("insert into #__core_acl_aro (section_value, value) values('users', $idLocal);");
        $database->query();
        $aro_id = $database->insertid();

        $database->setQuery("insert into #__core_acl_groups_aro_map (group_id,aro_id) values (18, $aro_id);");
        $database->query();
    }
}

//用户是否存在于CB comprofiler表中，若不存在则添加
// @param object(id, username,email)
// @return 
function checkuserexists_comprofiler(&$activeuser) {

    return;

    global $database;

    list($id, $username, $email) = $activeuser;
    $database->setQuery("select user_id from #__comprofiler where user_id=$id");
    if (!$database->loadRow()) {
        $database->setQuery("insert into #__comprofiler (id, user_id, approved, confirmed) values($id, $id, 1,1);");
        $database->query();
    }
}

//根据ucenter id获得通用username
function getUsername($id) {
    $arrTmp = uc_get_user(trim($id), TRUE);
    return $arrTmp[1];
}

?>
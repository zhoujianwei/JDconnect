<?php

define('UC_CLIENT_VERSION', '1.5.0'); //note UCenter 版本标识
define('UC_CLIENT_RELEASE', '20081031');

define('API_DELETEUSER', 1);  //note 用户删除 API 接口开关
define('API_RENAMEUSER', 1);  //note 用户改名 API 接口开关
define('API_GETTAG', 1);  //note 获取标签 API 接口开关
define('API_SYNLOGIN', 1);  //note 同步登录 API 接口开关
define('API_SYNLOGOUT', 1);  //note 同步登出 API 接口开关
define('API_UPDATEPW', 1);  //note 更改用户密码 开关
define('API_UPDATEBADWORDS', 1); //note 更新关键字列表 开关
define('API_UPDATEHOSTS', 1);  //note 更新域名解析缓存 开关
define('API_UPDATEAPPS', 1);  //note 更新应用列表 开关
define('API_UPDATECLIENT', 1);  //note 更新客户端缓存 开关
define('API_UPDATECREDIT', 1);  //note 更新用户积分 开关
define('API_GETCREDITSETTINGS', 1); //note 向 UCenter 提供积分设置 开关
define('API_GETCREDIT', 1);  //note 获取用户的某项积分 开关
define('API_UPDATECREDITSETTINGS', 1); //note 更新应用积分设置 开关

define('API_RETURN_SUCCEED', '1');
define('API_RETURN_FAILED', '-1');
define('API_RETURN_FORBIDDEN', '-2');

error_reporting(0);

//joomla library include files check this constant;
define('_VALID_MOS', 1);
define('UC_API', 1);
define('MAGIC_QUOTES_GPC', get_magic_quotes_gpc());

define('_JEXEC', 1);
define('JPATH_BASE', dirname(dirname(__FILE__)));
define('DS', DIRECTORY_SEPARATOR);
require_once ( JPATH_BASE . DS . 'config.inc.php' );
require_once ( JPATH_BASE . DS . 'includes' . DS . 'defines.php' );
require_once ( JPATH_BASE . DS . 'includes' . DS . 'framework.php' );
include_once('func_common.php');
include_once(JPATH_BASE . DS . 'uc_client' . DS . 'client.php');

$mainframe = & JFactory::getApplication('site');
$mainframe->initialise();
$database = & JFactory::getDBO();

$code = $_GET['code'];
parse_str(uc_authcode($code, 'DECODE', UC_KEY), $get);


if (MAGIC_QUOTES_GPC) {
    $get = dstripslashes($get);
}


if (time() - $get['time'] > 3600) {
    exit('Authracation has expiried');
}
if (empty($get)) {
    exit('Invalid Request');
}
$action = $get['action'];
$timestamp = time();


if ($action == 'test') {

    exit(API_RETURN_SUCCEED);
} elseif ($action == 'deleteuser') {

    !API_DELETEUSER && exit(API_RETURN_FORBIDDEN);

    //删除用户 API 接口
    $uids = $get['ids'];
    $arrUids = explode(',', $uids);
    foreach ($arrUids as $id) {
        $arrTmp = uc_get_user(trim($id), TRUE);
        $arrUsernames[] = "'" . $arrTmp[1] . "'";
    }

    $usernames = implode(",", $arrUsernames);
    $arrUidsNew = $database->setQuery("select id from #__users where username in ($usernames);");
    $uids = implode(',', $arrUidsNew);

    //todo:: clean all the content\pictures\files\videos, set their userid to 0
    //delete the user in joomla systable and comprofiler
    $database->setQuery("DELETE FROM #__users WHERE id IN ($uids);");
    $database->query();

    $database->setQuery("select aro_id FROM #__core_acl_aro WHERE value IN ($uids);");
    $aro_id = $database->loadResult();

    $database->setQuery("DELETE FROM #__core_acl_groups_aro_map WHERE aro_id IN ($aro_id);");
    $database->query();

    $database->setQuery("DELETE FROM #__core_acl_aro WHERE `value` IN ($uids);");
    $database->query();

    //$database->setQuery("DELETE FROM #__comprofiler WHERE user_id IN ($uids);");
    //$database->query();

    exit(API_RETURN_SUCCEED);
} elseif ($action == 'renameuser') {

    !API_RENAMEUSER && exit(API_RETURN_FORBIDDEN);

    //用户改名 API 接口
    $id = $get['uid'];

    $usernamenew = $get['newusername'];
    $activeuser = uc_get_user($id, 1);
    $username = $activeuser[1];

    //todo, the very first,we need to syn all the user table to prevent the username or id collision
    //Now we imagine everything is ok
    //if joomla user not exsits, add it
    checkuserexists_user($activeuser);
    $database->setQuery("update #__users set username='$usernamenew' WHERE username='$username';");
    $database->query();

    //if user in comprofiler not exsits, add it
    checkuserexists_comprofiler($activeuser);

    exit(API_RETURN_SUCCEED);
} elseif ($action == 'updatepw') {

    !API_UPDATEPW && exit(API_RETURN_FORBIDDEN);

    //新的ucenter版本中提供password
    $username = $get['username'];
    $password = $get['password'];

    $activeuser = uc_get_user($username);
    checkuserexists_user($activeuser);
    checkuserexists_comprofiler($activeuser);

    if ($password) {
        $database->setQuery("update #__users set password='" . md5($password) . "' WHERE username ='$username';");
        $database->query();
    }
    //J1.5仍支持将密码设置为md5

    exit(API_RETURN_SUCCEED);
} elseif ($action == 'synlogin' && $_GET['time'] == $get['time']) {
    //echo "hello";
    !API_SYNLOGIN && exit(API_RETURN_FORBIDDEN);

    //同步登录 API 接口
    $id = intval($get['uid']);

    // is uer exists?
    $activeuser = uc_get_user($id, 1);
    $username = $activeuser[1];

    checkuserexists_user($activeuser);
    checkuserexists_comprofiler($activeuser);

    $database->setQuery("select username, password from #__users where username='$username'");
    list($username, $password) = $database->loadRow();
    //exit($username.$password);
    header('P3P: CP="CURa ADMa DEVa PSAo PSDo OUR BUS UNI PUR INT DEM STA PRE COM NAV OTC NOI DSP COR"');
    $mainframe->login(array('username' => $username, 'password' => $password), array('checkpassword' => 'skip'));
    exit(API_RETURN_SUCCEED . ' ');
} elseif ($action == 'synlogout') {

    !API_SYNLOGOUT && exit(API_RETURN_FORBIDDEN);
    header('P3P: CP="CURa ADMa DEVa PSAo PSDo OUR BUS UNI PUR INT DEM STA PRE COM NAV OTC NOI DSP COR"');
    //同步登出 API 接口
    //当前应不需去除session表中记录
    $mainframe->logout();
    exit(API_RETURN_SUCCEED);
} else {
    exit(API_RETURN_FAILED);
}

function authcode($string, $operation = 'DECODE', $key = '', $expiry = 0) {

    $ckey_length = 4;

    $key = md5($key ? $key : UC_KEY);
    $keya = md5(substr($key, 0, 16));
    $keyb = md5(substr($key, 16, 16));
    $keyc = $ckey_length ? ($operation == 'DECODE' ? substr($string, 0, $ckey_length) : substr(md5(microtime()), -$ckey_length)) : '';

    $cryptkey = $keya . md5($keya . $keyc);
    $key_length = strlen($cryptkey);

    $string = $operation == 'DECODE' ? base64_decode(substr($string, $ckey_length)) : sprintf('%010d', $expiry ? $expiry + time() : 0) . substr(md5($string . $keyb), 0, 16) . $string;
    $string_length = strlen($string);

    $result = '';
    $box = range(0, 255);

    $rndkey = array();
    for ($i = 0; $i <= 255; $i++) {
        $rndkey[$i] = ord($cryptkey[$i % $key_length]);
    }

    for ($j = $i = 0; $i < 256; $i++) {
        $j = ($j + $box[$i] + $rndkey[$i]) % 256;
        $tmp = $box[$i];
        $box[$i] = $box[$j];
        $box[$j] = $tmp;
    }

    for ($a = $j = $i = 0; $i < $string_length; $i++) {
        $a = ($a + 1) % 256;
        $j = ($j + $box[$a]) % 256;
        $tmp = $box[$a];
        $box[$a] = $box[$j];
        $box[$j] = $tmp;
        $result .= chr(ord($string[$i]) ^ ($box[($box[$a] + $box[$j]) % 256]));
    }

    if ($operation == 'DECODE') {
        if ((substr($result, 0, 10) == 0 || substr($result, 0, 10) - time() > 0) && substr($result, 10, 16) == substr(md5(substr($result, 26) . $keyb), 0, 16)) {
            return substr($result, 26);
        } else {
            return '';
        }
    } else {
        return $keyc . str_replace('=', '', base64_encode($result));
    }
}

function dsetcookie($var, $value, $life = 0, $prefix = 1) {
    global $cookiedomain, $cookiepath, $timestamp, $_SERVER;
    setcookie($var, $value,
            $life ? $timestamp + $life : 0, $cookiepath,
            $cookiedomain, $_SERVER['SERVER_PORT'] == 443 ? 1 : 0);
}

function dstripslashes($string) {
    if (is_array($string)) {
        foreach ($string as $key => $val) {
            $string[$key] = dstripslashes($val);
        }
    } else {
        $string = stripslashes($string);
    }
    return $string;
}
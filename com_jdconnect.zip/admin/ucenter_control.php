<?php

// No direct access allowed to this file
defined('_JEXEC') or die('Restricted access');

// Import Joomla! Plugin library file
jimport('joomla.plugin.plugin');

// ucenter settings file
include_once(JPATH_ROOT . DS . "config.inc.php");
include_once(JPATH_ROOT . DS . "uc_client" . DS . "client.php");
include_once(JPATH_ROOT . DS . "api" . DS . "func_common.php");

//class plg<PluginGroup><PluginName> extends JPlugin
class plgUserUcenter_Control extends JPlugin {

    function plgUserUcenter_Control(& $subject, $config) {
        parent::__construct($subject, $config);
    }

    function onAfterDeleteUser($user, $succes, $msg) {
        if (!$succes) {
            return false;
        }

        $userinfo = uc_get_user($user['username'], 0);

        uc_user_delete($userinfo[0]);
    }

    function onLoginUser($user, $options = array()) {
        jimport('joomla.user.helper');

        $instance = & $this->_getUser($user, $options);

        // if _getUser returned an error, then pass it back.
        if (JError::isError($instance)) {
            return $instance;
        }

        // If the user is blocked, redirect with an error
        if ($instance->get('block') == 1) {
            return JError::raiseWarning('SOME_ERROR_CODE', JText::_('E_NOLOGIN_BLOCKED'));
        }

        $username = $instance->get('username');
        //$password = $instance->get('password');
        $password = $user['password'];

        //ucenter存在
        if (uc_user_checkname($username) == -3) {
            $activeuser = uc_get_user($username);

            //直接在ucenter中检查密码是否正确，若不正确则返回错误
            $arr_userlogininfo = uc_user_login($username, $password);
            list($id, $username, $password2, $email, $bln_isdoubled) = $arr_userlogininfo;

            //用户名ucenter中存在但密码错
            //TODO:初注册时可能两密码不等
            if ($id == -2) {
                //exit("hello".$password);
                return;
            }
        }

        //因在joomla中注册时资料总能进入ucenter库,因此若ucenter中用户不存在我们认为joomla中是过期数据
        else {
            return;
            /*
              //在ucenter中注册,此处并不判断id是否一致,可能导致问题
              $id = uc_user_register($user['username'], $user['password_clear'], $user['email']);

             */
        }

        //若为接受通知,则不必通知 ucenter	直接跳过
        //默认为从本地登录,需通知
        if ($options['checkpassword'] != 'skip') {
            $ucsynlogin = uc_user_synlogin($id);
            echo $ucsynlogin;
            //exit($id);
        }
    }

    function onLogoutUser($user) {
        // joomla header
        //header('P3P: CP="NOI ADM DEV PSAi COM NAV OUR OTRo STP IND DEM"');
        $ucsynlogin = uc_user_synlogout();
        echo $ucsynlogin;
    }

    function onBeforeStoreUser($user, $isnew) {
        //新$user内容并未传过来
        /*
          exit(var_dump($user));
          //检查ucenter中是否已有同名用户,若存在则返回消息
          $intResult = uc_user_checkname($user['username']);
          if($intResult!=1){
          //JError::raiseWarning('', JText::_( "username doesn't match our needs or has been used."));
          exit(JText::_("username doesn't match our needs.plz go back and rechoose."));
          }

          //检查ucenter中是否已有相同email,若存在则返回消息
          $intResult = uc_user_checkemail($user['email']);
          if($intResult!=1){
          //JError::raiseWarning('', JText::_( "email doesn't match our needs or has been used."));
          exit(JText::_( "email doesn't match our needs.plz go back and rechoose."));
          }
         */
    }

    //when $options->isnew
    //or !$options->isnew
    function onAfterStoreUser($user, $options = array(), $isnew) {
        //in j1.5.12, when set an old user block to 0 or store an old user, the $snew is 1 too!
        //if($isnew){
        //var_dump($user);
        //var_dump($isnew);
        //exit('we are here');
        //var_dump($user);
        //exit($user['password_clear']."--pass".$isnew);
        $id = uc_user_register($user['username'], $user['password_clear'], $user['email']);

        if ($id <= 0) {
            if ($id == -1) {
                echo ( "用户名不合法" );
            } elseif ($id == -2) {
                echo ( "包含要允许注册的词语" );
            } elseif ($id == -3) {
                // 用户名已存在,直接更改ucenter中资料
                $activeuser = uc_get_user($user['username']);
                uc_user_edit($user['username'], '', $user['password_clear'], $user['email'], 1);
                //checkuserexists_user($activeuser);
                //checkuserexists_comprofiler($activeuser);
                //echo ( "用户名已经存在" );
            } elseif ($id == -4) {
                echo ( "Email 格式有误" );
            } elseif ($id == -5) {
                echo ( "Email 不允许注册" );
            } elseif ($id == -6) {
                echo ( "该 Email 已经被注册" );
            } else {
                echo ( "未定义错误" );
            }
        }
    }

    function &_getUser($user, $options = array()) {
        $instance = new JUser();
        if ($id = intval(JUserHelper::getUserId($user['username']))) {
            $instance->load($id);
            return $instance;
        }

        //TODO : move this out of the plugin
        jimport('joomla.application.component.helper');
        $config = &JComponentHelper::getParams('com_users');
        $usertype = $config->get('new_usertype', 'Registered');

        $acl = & JFactory::getACL();

        $instance->set('id', 0);
        $instance->set('name', $user['fullname']);
        $instance->set('username', $user['username']);
        $instance->set('password_clear', $user['password_clear']);
        $instance->set('email', $user['email']); // Result should contain an email (check)
        $instance->set('gid', $acl->get_group_id('', $usertype));
        $instance->set('usertype', $usertype);

        //If autoregister is set let's register the user
        $autoregister = isset($options['autoregister']) ? $options['autoregister'] : $this->params->get('autoregister', 1);

        if ($autoregister) {
            if (!$instance->save()) {
                return JError::raiseWarning('SOME_ERROR_CODE', $instance->getError());
            }
        } else {
            // No existing user and autoregister off, this is a temporary user.
            $instance->set('tmp_user', true);
        }

        return $instance;
    }

}

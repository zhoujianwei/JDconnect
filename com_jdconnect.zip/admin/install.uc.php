<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
// No direct access allowed to this file
defined('_JEXEC') or die('Restricted access');

function com_install() {
    jimport('joomla.filesystem.file');
    jimport('joomla.filesystem.folder');
    // if extract file use this
    //jimport('joomla.filesystem.archive');
    //
    $path1 = JPATH_PLUGINS . DS . 'authentication';
    JFile::move($path1 . DS . 'joomla.php', $path1 . DS . 'joomla.php.bk');
    JFile::move(dirname(__FILE__) . DS . 'joomla.php', $path1 . DS . 'joomla.php');

    $path1 = JPATH_ROOT . DS . 'components' . DS . 'com_user';
    JFile::move($path1 . DS . 'controller.php', $path1 . DS . 'controller.php.bk');
    JFile::move(dirname(__FILE__) . DS . 'controller.php', $path1 . DS . 'controller.php');
    //
    $path1 = JPATH_ADMINISTRATOR . DS . 'components' . DS . 'com_jdconnect';
    JFolder::move($path1 . DS . 'uc_client', JPATH_ROOT . DS . 'uc_client');
    JFolder::move($path1 . DS . 'api', JPATH_ROOT . DS . 'api');

    // plugin install
    // use compressed file
    // $file=dirname(__FILE__).DS.'plug.zip';
    // JArchive::extract($file, JPATH_PLUGINS.DS.'user');
    $path1 = JPATH_ADMINISTRATOR . DS . 'components' . DS . 'com_jdconnect';
    JFile::move($path1 . DS . 'ucenter_control.xml.php', JPATH_PLUGINS . DS . 'user' . DS . 'ucenter_control.xml');
    JFile::move($path1 . DS . 'ucenter_control.php', JPATH_PLUGINS . DS . 'user' . DS . 'ucenter_control.php');

    $db = & JFactory::getDBO();
    $sql = "INSERT INTO `#__plugins` (name, element, folder, published) VALUES ('JD UCenter Control', 'ucenter_control', 'user', 1);";
    $db->setQuery($sql);
    $db->Query();
?>
    <div style="text-align:left;">
        <table width="100%" border="0">
            <tr>
                <td>
                    <img src="../administrator/components/com_jdconnect/JDconnect.gif" />
                </td>
            </tr>
            <tr>
                <td>
                    <br />具体信息请查看 <a href="http://www.joomladrupal.com">www.joomladrupal.com</a>
                    <br />
                </td>
            </tr>
            <tr>
        </table>
    </div>
<?php
}
?>
